use BikeStores;

--1. soru
SELECT product_name, brand_name,category_name FROM production.products
INNER JOIN production.brands ON production.products.brand_id=production.brands.brand_id
INNER JOIN production.categories ON production.products.category_id=production.categories.category_id
WHERE production.products.model_year=2016 AND production.products.list_price>500;

--2. soru
SELECT COUNT(*)
FROM production.products
LEFT JOIN sales.order_items ON production.products.product_id = sales.order_items.product_id
WHERE sales.order_items.product_id IS NULL;

--3.soru
SELECT MAX(sales.order_items.list_price) AS MaxSiparisTutari
FROM sales.customers
RIGHT JOIN sales.orders ON sales.customers.customer_id = sales.orders.customer_id
RIGHT JOIN sales.order_items ON sales.orders.order_id = sales.order_items.order_id
WHERE sales.customers.first_name = 'Mercy' AND sales.customers.last_name = 'Brown';

--4. soru
SELECT sales.stores.store_name FROM sales.stores
FULL JOIN sales.orders ON sales.stores.store_id = sales.orders.store_id
WHERE sales.stores.store_id IS NULL;

--5.soru
SELECT DISTINCT p1.product_name
FROM production.products p1
JOIN production.categories p2 ON p1.category_id = p2.category_id
WHERE p2.category_name= 'Cruisers Bicycles' AND p1.product_id <> p2.category_id;

--6. soru
SELECT COUNT(DISTINCT product_id) AS Toplam_Urun
FROM production.products
JOIN production.brands ON production.products.brand_id=production.brands.brand_id
WHERE production.brands.brand_name='Trek';







