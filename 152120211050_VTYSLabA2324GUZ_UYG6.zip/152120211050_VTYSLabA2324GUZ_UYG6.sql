use BikeStores;

--SORU1
--Her bir y�neticinin (manager) kimli�i (staff_id), ad� (first_name), soyad� (last_name) ve
--y�netti�i �al��anlar�n (staff) say�s�n� i�eren sorguyu yaz�n�z
SELECT m.staff_id, m.first_name , m.last_name , COUNT(s.staff_id) AS number_of_staff
FROM sales.staffs s
INNER JOIN sales.staffs m ON s.manager_id = m.staff_id
GROUP BY m.staff_id, m.first_name, m.last_name;

--SORU2
--Belirli bir ma�azada (stores) stokta (stocks) bulunan miktar� (quantity) 26�dan fazla olan
--�r�nlerin (products) isimlerini (product_name) listeleyiniz 
--ANY kullanarak yap�n�z!
SELECT p.product_name
FROM production.products p
WHERE p.product_id = ANY (
    SELECT s.product_id
    FROM production.stocks s
	JOIN sales.stores st ON s.store_id=st.store_id
    WHERE s.quantity > 26 )

--SORU3
--Belirli bir ma�azada (stores) stokta (stocks) bulunan ve stok miktar� (quantity) tam olarak
--26 olan t�m �r�nlerin (products) isimlerini (product_name) listeleyiniz (15p).
--ALL kullanarak yap�n�z!
	SELECT 
    p.product_name
FROM 
    production.products p
JOIN 
    production.stocks s ON p.product_id = s.product_id
WHERE 
    26 = ALL (SELECT quantity FROM production.stocks JOIN sales.stores st ON s.store_id=st.store_id WHERE s.product_id = product_id);

--SORU4
--Stokta (Stocks) miktar� (quantity) tam olarak 30 olan ve ayn� zamanda �r�n (products) fiyat�
--(list_price) 3000�den y�ksek olan en az bir �r�n�n (products) bulundu�u ma�azalar�n
--(stores) isimlerini (store_name) listeleyiniz 
--EXISTS kullanarak yap�n�z!
SELECT 
    s.store_name
FROM 
    sales.stores s
WHERE 
    EXISTS (
        SELECT 1
        FROM 
            production.products p
        JOIN 
            production.stocks st ON p.product_id = st.product_id
        WHERE 
            st.store_id = s.store_id
            AND st.quantity = 30
            AND p.list_price > 3000
    );

--SORU5
--�Santa Cruz Bikes� adl� ma�azadan (stores) al��veri� (orders) yapan her bir �ehirdeki (city)
--m��teri (customers) say�s�n� hesaplay�n�z. M��teri (customers) say�s� 10�dan fazla olan
--�ehirleri (city) se�iniz ve bu �ehirleri (city) m��teri (customers) say�s�na g�re azalan s�rayla
--listeleyiniz 
--HAVING kullanarak yap�n�z!
SELECT 
    c.city,
    COUNT(c.customer_id) AS customer_count
FROM 
    sales.customers c
JOIN 
    sales.orders o ON c.customer_id = o.customer_id
JOIN 
    sales.stores s ON o.store_id = s.store_id
WHERE 
    s.store_name = 'Santa Cruz Bikes'
GROUP BY 
    c.city
HAVING 
    COUNT( c.customer_id) > 10
ORDER BY 
    customer_count DESC;


--SORU6
--�Baldwin Bikes� adl� ma�azadan (stores) sipari� (orders) vermeyen m��terilerin
--(customers) isimlerini (first_name) ve soyisimlerini (last_name) listeleyiniz 
--EXCEPT kullanarak yap�n�z!
SELECT 
    first_name,
    last_name
FROM 
    sales.customers
EXCEPT
SELECT 
    c.first_name,
    c.last_name
FROM 
    sales.customers c
JOIN 
    sales.orders o ON c.customer_id = o.customer_id
JOIN 
    sales.stores s ON o.store_id = s.store_id
WHERE 
    s.store_name = 'Baldwin Bikes';











