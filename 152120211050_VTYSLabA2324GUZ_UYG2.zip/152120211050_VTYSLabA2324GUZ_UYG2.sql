CREATE DATABASE k2;
USE k2;

CREATE TABLE Kitaplar (
KitapID INT not NULL,
YazarID INT not NULL,
KitapAdi varchar(100) not NULL,
ISBN varchar(13) not NULL,
YayinEvi varchar(100),
BasimTarihi date,
StokAdeti INT,
PRIMARY KEY (KitapID),
)

CREATE TABLE Yazarlar (
YazarID INT not NULL,
Ad varchar(50) not NULL,
Soyad varchar(50) not NULL,
DogumTarihi date,
Ulke varchar(50),
PRIMARY KEY (YazarID))

CREATE TABLE OduncAlinanKitaplar(
OduncID INT not NULL,
KitapID INT not NULL,
UyeID INT not NULL,
AlisTarihi date,
TeslimTarihi date,
PRIMARY KEY (OduncID))

CREATE TABLE KutuphaneUyeleri(
UyeID INT not NULL,
Ad varchar(50) not NULL,
Soyad varchar(50) not NULL,
Telefon varchar(15),
Adres varchar(255),
PRIMARY KEY (UyeID))

ALTER TABLE Kitaplar ADD FOREIGN KEY (YazarID) REFERENCES Yazarlar(YazarID);
ALTER TABLE OduncAlinanKitaplar ADD FOREIGN KEY (KitapID) REFERENCES Kitaplar(KitapID);
ALTER TABLE OduncAlinanKitaplar ADD FOREIGN KEY (UyeID) REFERENCES KutuphaneUyeleri(UyeID);


