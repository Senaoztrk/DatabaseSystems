use BikeStores;

--1) �r�nler(products) tablosundaki yer alan �r�nlerden en d���k �r�n fiyat�n� ve en y�ksek
--�r�n fiyat�n� ekrana listeleyiniz
SELECT MIN(list_price) AS MIN_PRICE, MAX(list_price) AS MAX_PRICE FROM production.products;

--2) �r�nler(products) tablosundaki yer alan �r�nlerin toplam say�s�n�, toplam fiyat�n� ve
--ortalama fiyat�n� ekrana listeleyiniz
SELECT COUNT (product_id) AS NUM_PRODUCT,SUM(list_price) AS SUM_PRICE,AVG(list_price) AS AVG_PRICE FROM production.products;

--3) 'Santa Cruz Bikes' ma�azas�ndan(stores) sipari�(orders) veren 5 adet m��teriyi(customers)
--listeleyiniz. Ad ve soyad bilgilerini ekrana yazd�r�n�z
SELECT TOP 5 first_name AS NAME,last_name AS SURNAME FROM sales.customers,sales.stores WHERE store_name='Santa Cruz Bikes';

--4) Ad�n�n ikinci harfi S ve soyad�n�n son harfi A olan t�m m��terileri(customers) listeleyiniz.
--Ad ve soyad bilgilerini ekrana yazd�r�n�z
SELECT first_name,last_name FROM sales.customers WHERE first_name LIKE '_S%' AND last_name LIKE '%A';

--5) Model y�l� 2015 ve 2017 dahil olmak �zere bu y�llar aras�ndaki �r�nleri(products) sipari�
--etmi� (order_items & orders) m��terileri(customers) listeleyiniz. Ad ve soyad bilgilerini
--e�siz olarak ekrana yazd�r�n�z (20p). Bu soruyu ger�ekle�tirirken BETWEEN kullan�n�z.
SELECT  DISTINCT first_name AS NAME ,last_name AS SURNAME FROM sales.customers,sales.orders,production.products WHERE model_year BETWEEN 2015 AND 2017;

--6) 'Santa Cruz Bikes' ve 'Baldwin Bikes' ma�azalar�ndan(stores) sipari�(orders) veren 10 adet
--m��teriyi(customers) listeleyiniz (20p). Ad ve soyad bilgilerini ekrana yazd�r�n�z. Bu
--soruyu ger�ekle�tirirken IN kullan�n�z.
SELECT first_name AS NAME, last_name AS SURNAME from sales.stores,sales.orders,sales.customers WHERE store_name IN ('Santa Cruz Bikes','Baldwin Bikes');

