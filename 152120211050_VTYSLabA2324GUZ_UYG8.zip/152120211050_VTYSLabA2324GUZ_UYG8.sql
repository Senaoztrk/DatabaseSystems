use BikeStores

--SORU1
CREATE TRIGGER trg_DeleteCustomers
ON sales.customers
AFTER DELETE
AS
BEGIN
    DELETE FROM orders
	WHERE customer_id IN (SELECT customer_id FROM deleted);
END;

DELETE FROM customers
WHERE customer_id = 2;

GO

--SORU2
CREATE TRIGGER trg_AddOrder
ON production.stocks
AFTER INSERT
AS
BEGIN
    UPDATE stocks
	SET quantity=stocks.quantity-i.quantity
	From Products
	INNER JOIN inserted i ON products.product_id=i.product_id
END;
INSERT INTO production.stocks(store_id,product_id,quantity)
VALUES (1,1,1);

GO;

--SORU3
CREATE TRIGGER trg_DeleteStockOnProductss
ON production.products
AFTER DELETE
AS
BEGIN
    
    DELETE FROM stocks
    WHERE product_id IN (SELECT product_id FROM deleted);
END;
    
DELETE FROM Products
WHERE product_id = 1;
GO

--SORU4
CREATE TRIGGER trg_DeleteStockOnProductDelete
ON production.products
AFTER DELETE
AS
BEGIN
    -- Silinen �r�n�n ID'sini bul
    DECLARE @newproduct_id INT;
    SELECT @newproduct_id = product_id FROM inserted;

	INSERT INTO stocks(product_id, store_id, quantity)
	SELECT @newproduct_id, store_id, 0
	FROM stocks;
END;

INSERT INTO Products (product_name, category_id)
VALUES ('New Product', 1);















