--SORU1
CREATE PROCEDURE SiparisDetayListele
    @MusteriID INT
AS
BEGIN
    SELECT 
        M.first_name,
        M.last_name,
        S.order_id,
		S.order_date,
		S.order_status,
		S.required_date,
		S.shipped_date,
		S.store_id,
		S.staff_id
     FROM 
        sales.orders S
    JOIN
        sales.customers M ON S.customer_id = M.customer_id
	JOIN
	    sales.order_items SD ON  SD.order_id=S.order_id
    WHERE 
        M.customer_id = @MusteriID;
END;

EXEC SiparisDetayListele @MusteriID = 1; 
--DROP PROCEDURE SiparisDetayListele

--SORU2
ALTER PROCEDURE SiparisDetayListele
    @firstname nvarchar(50),
    

AS
BEGIN
    SELECT TOP 1
        M.first_name,
		M.last_name,
        S.order_id,
        S.order_date,
        SD.product_id,
        SD.quantity,
        SD.list_price
    FROM 
        sales.orders S
    JOIN
        sales.customers M ON M.customer_id = S.customer_id
    JOIN
        sales.order_items SD ON S.order_id = SD.order_id
    WHERE 
        M.first_name = @firstname 
    ORDER BY
        SD.list_price DESC;
END;

EXEC SiparisDetayListele @firstname = 'Debra';


--SORU3
CREATE PROCEDURE SiparisToplamDeger
    @MusteriID INT
AS
BEGIN
    SELECT 
        S.store_id,
        SUM(SD.quantity * SD.list_price) AS ToplamDeger
    FROM 
        sales.orders S
    JOIN
        sales.order_items SD ON S.order_id = SD.order_id
    WHERE 
        S.customer_id = @MusteriID
    GROUP BY 
        S.store_id;
END;
EXEC SiparisToplamDeger @MusteriID=1;

--SORU4
--DROP PROCEDURE EnYuksekVeEnDusukFiyatliUrunDetay
CREATE PROCEDURE EnYuksekVeEnDusukFiyatliUrunDetay
     @category INT
AS
BEGIN
    SELECT 
        (SELECT MAX(list_price) FROM production.products)  AS MAXFiyat,
        P1.product_name,
        PB.brand_name,
        PC.category_name
        
	FROM 
        production.products P1
	JOIN
	    production.categories PC ON P1.category_id=PC.category_id
	JOIN
	    production.brands PB ON P1.brand_id=PB.brand_id
    WHERE 
        @category=PC.category_id;

    SELECT 
        
        P2.product_name,
        PB.brand_name,
        PC.category_name,
        P2.list_price,
		(SELECT MIN(list_price) FROM production.products) AS MINFiyat
    FROM 
        production.products P2
	JOIN
	    production.categories PC ON P2.category_id=PC.category_id
	JOIN
	    production.brands PB ON P2.brand_id=PB.brand_id
   
	WHERE
		@category=PC.category_id;

END;
EXEC EnYuksekVeEnDusukFiyatliUrunDetay @category=3;




